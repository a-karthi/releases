//
// This file is auto-generated. Please don't modify it!
//
#pragma once

#ifdef __cplusplus
//#import "opencv.hpp"
#import "opencv2/wechat_qrcode.hpp"
#else
#define CV_EXPORTS
#endif

#import <Foundation/Foundation.h>





NS_ASSUME_NONNULL_BEGIN

// C++: class Wechat_qrcode
/**
 * The Wechat_qrcode module
 *
 * Member classes: `WeChatQRCode`
 *
 */
CV_EXPORTS @interface Wechat_qrcode : NSObject

#pragma mark - Methods



@end

NS_ASSUME_NONNULL_END


